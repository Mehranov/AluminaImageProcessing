% By running this code you can select your SEM image and it will be
% modified to be prepared to be analyzed by the rest of the code. Generally
% this code will produce the complement of the image because we need the
% pores to be white in image (or the maxima of the image) to replace them
% with pixels.
[FileName,PathName] = uigetfile({'*.png';'*.*'},'Select the SEM Image in .PNG format');
Path=strcat(PathName,FileName);
imorig=importdata(Path);
im=imcomplement(rgb2gray(imorig));
%im=imgaussfilt(im);
clear imorig FileName PathName Path;


